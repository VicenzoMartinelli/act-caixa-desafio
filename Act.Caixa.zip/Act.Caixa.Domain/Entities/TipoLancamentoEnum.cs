﻿namespace Act.Caixa.Domain.Entities;

public enum TipoLancamentoEnum
{
    Entrada,
    Saida
}   