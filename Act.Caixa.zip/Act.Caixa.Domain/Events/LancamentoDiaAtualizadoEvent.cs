﻿namespace Act.Caixa.Domain.Events;

public class LancamentoDiaAtualizadoEvent
{
    public DateOnly Data { get; set; }
}